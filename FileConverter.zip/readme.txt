We provide two tools to convert bin file into csv file:Bin2csv.exe and Convert_bin_to_csv_file.py . 

The exe application can be used directly.
Steps:
Double click to run the exe;
Click "Browse" to select the bin file that needs to be converted;
Select the model of the bin file;
Click "Convert" to start the conversion;
(When the number of data points is large, the time of the conversion may be longer. Please be patient.)
The path of the file generated after the conversion is the path of the bin file,and named as "csv_data.csv".

The python file is to facilitate you to understand the conversion process, only for reference. 
You need to install the corresponding library files before using, and if necessary, the code needs to be modified.

Note:
1.Only support for SDS1000X-E\SDS2000X-E\SDS5000X series temporarily;
2.SDS1000X-E needs to upgrade to the software version after V6.1.25R3 while there has no restrictions on the version of SDS2000X-E and SDS5000X;
3.The conversion of digital channels is not supported at present;
4.We have tested the Bin2csv.exe on the systems: WinXP(32 bit)\Win7(32\64 bit)\Win10(64 bit).

Change log:
Bin2csv.exe(V2.0)
1.Support for SDS2000X+;
2.Contain the probe information. Must match the version of the models:
SDS1000X-E&SDS2000X-E (not contain)
SDS5000X (V0.8.7 or later)
SDS2000X+ (any version)

Bin2csv.exe(V3.0)
1��Support for Digital
2��Separate the analog and digital channel data to save into 2 files��Analog_Trace.csv, Digital_Trace.csv

Bin2csv.exe(V3.1)
1��Support for models��
SDS6000Pro(V1.1.3.0 or later)
SDS2000X+(version higher than 1.3.5R3)
SDS5000X(version higher than 0.9.1)
SDS1000X-E(any version)
SDS2000X-E(any version)
2��Synchronizate the modification of the binary file header, no need to select the model

Bin2csv.exe(V3.2)
Modify build csv file naming policy��the file name of the bin file, added with the analog/digital channel flag.
Such as:1k_c2_d0-7.bin ->1k_c2_d0-7_Analog_Trace.csv & 1k_c2_d0-7_Digital_Trace.csv

Bin2csv.exe(V3.3)
Support for SDS6000 H10 Pro(V1.1.8.0 or later)

FileConverter.exe(V3.4)
1��Modify the application name to "FileConverter"
2��Support for Math(except FFT),it needs to match the Firmware version below:
SDS6000Pro(version higher than 1.2.2.0)
SDS1000X-E(V6.1.36 or later)
3��New support models
SDS2000X (V1.2.2.2 R25 or later)

FileConverter.exe(V3.5)
Support to convert binary file(*.slg,*.mlg) of Data Logger with SDS1004X-E(V6.1.36R8 or later)
